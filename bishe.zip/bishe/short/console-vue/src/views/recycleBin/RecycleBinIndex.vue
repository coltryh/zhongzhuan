<template>
  <div>
    回收站
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>